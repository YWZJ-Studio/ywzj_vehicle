package com.github.mcmodderanchor.simplebedrockmodel.v1.client.compat.embeddium;


import com.github.mcmodderanchor.simplebedrockmodel.v1.common.model.BedrockCubeBox;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.embeddedt.embeddium.api.vertex.buffer.VertexBufferWriter;
import org.embeddedt.embeddium.impl.render.vertex.VertexConsumerUtils;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class EmbeddiumBedrockCubeBox extends BedrockCubeBox implements IEmbeddiumVertexWriter {
    public EmbeddiumBedrockCubeBox(float texOffX, float texOffY, float x, float y, float z, float width, float height, float depth, float delta, boolean mirror, float texWidth, float texHeight) {
        super(texOffX, texOffY, x, y, z, width, height, depth, delta, mirror, texWidth, texHeight);
    }

    @Override
    public void compile(PoseStack.Pose pose, Vector3f[] normals, VertexConsumer consumer, int lightmap, int overlay, float r, float g, float b, float a) {
        VertexBufferWriter writer = VertexConsumerUtils.convertOrLog(consumer);
        if (writer == null) {
            super.compile(pose, normals, consumer, lightmap, overlay, r, g, b, a);
            return;
        }

        Matrix4f matrix4f = pose.pose();
        prepareVertices(matrix4f);
        prepareNormals(normals);
        int color = (int) (a * 255.0f) << 24 | (int) (b * 255.0f) << 16 | (int) (g * 255.0f) << 8 | (int) (r * 255.0f);

        int vertexCount = 0;
        long ptr = SCRATCH_BUFFER;

        boolean enableCulling = RenderSystem.getModelViewMatrix().m32() == 0;
        for (int i = 0; i < NUM_CUBE_FACES; i++) {
            if (enableCulling && !shouldRenderFace(i, normals)) continue;
            emitVertex(ptr, VERTICES[VERTEX_ORDER[i][0]].x, VERTICES[VERTEX_ORDER[i][0]].y, VERTICES[VERTEX_ORDER[i][0]].z,
                    color, uvs[uvOrder[i][1]], uvs[uvOrder[i][2]], overlay, lightmap, NORMALS[i]);
            ptr += STRIDE;

            emitVertex(ptr, VERTICES[VERTEX_ORDER[i][1]].x, VERTICES[VERTEX_ORDER[i][1]].y, VERTICES[VERTEX_ORDER[i][1]].z,
                    color, uvs[uvOrder[i][0]], uvs[uvOrder[i][2]], overlay, lightmap, NORMALS[i]);
            ptr += STRIDE;

            emitVertex(ptr, VERTICES[VERTEX_ORDER[i][2]].x, VERTICES[VERTEX_ORDER[i][2]].y, VERTICES[VERTEX_ORDER[i][2]].z,
                    color, uvs[uvOrder[i][0]], uvs[uvOrder[i][3]], overlay, lightmap, NORMALS[i]);
            ptr += STRIDE;

            emitVertex(ptr, VERTICES[VERTEX_ORDER[i][3]].x, VERTICES[VERTEX_ORDER[i][3]].y, VERTICES[VERTEX_ORDER[i][3]].z,
                    color, uvs[uvOrder[i][1]], uvs[uvOrder[i][3]], overlay, lightmap, NORMALS[i]);
            ptr += STRIDE;
            vertexCount += 4;
        }

        flush(writer, vertexCount);
    }

    private boolean shouldRenderFace(int face, Vector3f[] normals) {
        int[] verts = VERTEX_ORDER[face];
        float cx = VERTICES[verts[0]].x + VERTICES[verts[2]].x;
        float cy = VERTICES[verts[0]].y + VERTICES[verts[2]].y;
        float cz = VERTICES[verts[0]].z + VERTICES[verts[2]].z;
        return cx * normals[face].x + cy * normals[face].y + cz * normals[face].z <= 0;
    }
}